# Execution Plan — JS Quality Refactor
### Phase 3 output, per `ai-task-execution-methodology.md`

| | |
|---|---|
| **Concept** | `chessboard-js-refactor-concept-1a.md` |
| **Built from** | `chessboard-js-refactor-task-map-1a.json` (9 issues) |
| **Source** | `chessboard-1d.html` → target `chessboard-1e.html` |
| **Status** | **Plan only — NOT executed** |

---

## Legend

- `[ ]` pending · `[x]` done
- `(requires: X)` — blocking, must land in an earlier pass
- `(domino: X)` — same pass, same group
- `(cross-cutting)` — woven into every pass below, not a separate final sweep

---

## Execution order and why

```
1. board-rules       — HIGH, zero dependencies, and the highest-value extraction
                        (turns the riskiest logic into the cheapest-to-test logic)
2. board-renderer     — HIGH, zero dependencies, independent of rules
3. board-input        — HIGH, zero dependencies, independent of the above two
4. board-controller   — MEDIUM, but requires all three of the above to exist first
5. documentation      — cross-cutting, applied inside passes 1-4, not after them
6. constants          — cross-cutting, applied inside passes 1-4, not after them
```

Groups 1–3 have no dependency on each other and could be done in any order; 4 is last because it depends on all three. Documentation and constants are listed separately in the map (for tracking) but are executed as part of whichever pass touches that code, per the concept doc's decision to document-as-you-go.

---

## 1 · `board-rules` — 1 HIGH · 1 MEDIUM · 1 LOW

```
EXTRACTION
└── [ ] refactor-001 — pull _squareName, _squareFromName, _isPathClear,
                        _isPseudoLegal, _legalTargetsFrom, _createStartPosition
                        into a standalone ChessRules class — zero DOM, zero
                        this._root, testable in plain Node

SIGNATURE
└── [ ] refactor-002 — _isPseudoLegal(from, to) / _tryMove(from, to) as
                        {row, col} pairs instead of 4 positional numbers
                        (domino: refactor-001)

OPTIONAL
└── [ ] refactor-003 — MOVE_RULES dispatch table instead of the switch;
                        not required for this refactor to be considered done
```

## 2 · `board-renderer` — 1 HIGH

```
EXTRACTION
└── [ ] refactor-004 — pull _renderCoordinates, _render, _createPieceElement,
                        _pieceLabel into a BoardRenderer class — DOM
                        construction from a state snapshot, nothing else
```

## 3 · `board-input` — 2 HIGH

```
EXTRACTION
└── [ ] refactor-005 — pull _handleSquareActivate, _bind, _onClick,
                        _onKeydown, _onPointerDown, _clearDragOverState into
                        a BoardInputController that reports gestures upward
                        instead of calling _tryMove directly

COMPLEXITY
└── [ ] refactor-006 — while relocating it, split _onPointerDown's 4 inline
                        closures into named methods on BoardInputController
                        (domino: refactor-005) — this is the method that
                        independently failed both the length and branch-count
                        thresholds in the prior analysis
```

## 4 · `board-controller` — 1 MEDIUM

```
SLIM DOWN
└── [ ] refactor-007 — BoardController keeps constructor, config, this._state,
                        applyMove()/_tryMove(), reset(), destroy(), and wires
                        the three collaborators above. Target ~120-150 lines,
                        down from 397. (requires: refactor-001, refactor-004,
                        refactor-005)
```

## 5 · `documentation` (cross-cutting) — 1 MEDIUM

```
JSDOC RETROFIT
└── [ ] refactor-008 — JSDoc on every class + public method, added inside
                        passes 1-4 as each class is touched, per
                        zero-comments-rules-middle-1's format. Currently 0/8
                        classes compliant, verified by grep.
```

## 6 · `constants` (cross-cutting) — 1 MEDIUM

```
NAMED CONSTANTS
└── [ ] refactor-009 — MS_PER_MINUTE + LOW_TIME_THRESHOLD_MS on
                        ClockController (removes a 2-site duplication too);
                        separate names for the two coincidentally-equal
                        250s (clock tick vs. invalid-flash duration)
```

---

## Scope guard

`ChessPageController` and the other 6 widgets (`HeaderNavController`, `PlayerCardController`, `ClockController`, `MoveInputController`, `MovesController`, `SettingsModalController`) are not touched — the event contract (`board:move-made`, `board:illegal-move`, etc.) stays exactly as it is. This is an internal restructuring of one widget, not a change to how the page composes it.

## Next step

Once approved, this becomes Phase 4 against `chessboard-1d.html` → `chessboard-1e.html`. **Not run yet.**

Total tracked: **9 issues** — 4 HIGH · 4 MEDIUM · 1 LOW.
