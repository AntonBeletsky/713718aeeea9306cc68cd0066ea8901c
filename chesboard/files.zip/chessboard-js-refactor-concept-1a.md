# JS Quality Refactoring — Concept
### Target: enterprise-grade, architecturally clean JS for the chessboard project

| | |
|---|---|
| **Builds on** | The JS-quality analysis of `chessboard-1d.html` (current conversation): 0 JSDoc across 839 lines, `BoardController` at 397 lines (God Object candidate), `_onPointerDown` at 62 lines / ~12 branches, magic numbers, a 4-param data clump |
| **Governed by** | `containerization-11`, `containerization-orchestration-2`, `zero-comments-rules-middle-1`, `version-control-1b` (established), plus `DESIGN_SOFTWARE_GUIDE_ASGUARD01.md` and `sys_standarts_full_guide.md` (newly applied) |
| **Status** | Concept — precedes the Phase 1–3 breakdown below |

---

## 1. Goal

Take the codebase from "correctly working, flat, undocumented" to "correctly working, decomposed by responsibility, documented, and free of the specific anti-patterns the analysis measured" — without discarding any of the architectural discipline already in place (Law Zero, three-layer config, `AbortController` lifecycle, the page-level orchestrator pattern).

## 2. The core architectural move

`BoardController` is the one place the God Object smell is real. It currently owns four distinct concerns in one 397-line class: **rules** (is this move legal), **rendering** (build the DOM from state), **input** (click/keyboard/drag), and **orchestration** (state + lifecycle + the public API). SOLID's SRP says split these. `containerization-11` says a widget is one self-contained file with one public Controller. Both are satisfiable at once: split **inside** the file, as internal collaborators the Controller composes, and keep exactly one class exported to the rest of the page.

```
BoardController (orchestrator — public surface, ~120-150 lines)
├── ChessRules        — pure: legality, path-checking, starting position, notation
├── BoardRenderer      — pure DOM construction from a state snapshot
└── BoardInputController — click / keyboard / pointer-drag, reports gestures upward
```

This is the same orchestrator shape already used one level up (`ChessPageController` composing 7 widgets) — applied a second time, one level down, inside a single widget. Not a new pattern; the existing one, used consistently at a smaller scale.

The practical payoff that matters most: `ChessRules` becomes a plain class with no `this._root`, no DOM, no events — every legality rule can be unit-tested in bare Node, with no jsdom, no shims. The prior investigation into the drag bug already showed jsdom can't exercise the DOM/pointer side of `BoardController` properly; pulling the rules out of that entanglement means the part of the board that's easiest to get subtly wrong (movement legality) becomes the part that's cheapest to test exhaustively.

## 3. Key decisions

- **DRY vs. widget self-containment — self-containment wins.** `sys_standarts_full_guide.md` treats DRY as close to inviolable; `containerization-11` requires each widget file to be extractable with zero shared dependencies. Where they conflict — small constants, the `_esc()`-style helper, the `_bind()` boilerplate shape — this project has already chosen self-containment (see `_esc()` in the original build). This concept keeps that choice: `ChessRules`/`BoardRenderer`/`BoardInputController` live **inside** `chessboard-1d.html` next to `BoardController`, not as a shared module other widgets import.
- **`_isPseudoLegal`'s switch stays a switch.** Mechanically it scores high on cyclomatic complexity, but a switch over six known piece types is more readable than an equivalent branch count spread across nested ifs. A dispatch-table version is offered as an optional, separately-tracked item — not required for this refactor to count as done.
- **Documentation is retrofitted as each piece is touched, not as a separate final pass.** Every extraction in Phase 4 ships its JSDoc in the same edit, per `zero-comments-rules-middle-1`'s format (named headers, no `§` references, no internal jargon in the comments themselves).
- **No new dependency, no framework, no build step.** The refactor changes internal structure, not the deployment model (still one static HTML file).

## 4. Explicit non-goals

- Not touching move legality's actual rules (still no check/checkmate detection — that boundary was set in the original spec and stays).
- Not changing the cross-widget event contract (`board:move-made` etc.) — `ChessPageController` and the other 6 widgets should not need to change at all.
- Not introducing a shared base class or a cross-widget utility file.
- Not chasing the cyclomatic-complexity number on `_isPseudoLegal` below what a plain switch already gives.

## 5. Success criteria

- No class over ~150 lines without a documented reason.
- Every class and every public method carries JSDoc.
- No function over 40 lines or ~10 branches, except by recorded exception (the switch).
- No 4-positional-parameter functions where the parameters travel in pairs — `{row, col}` throughout.
- Every previously-identified magic number has a name.
- `ChessRules` runs its own tests in plain Node, no browser/DOM shim required.
- `ChessPageController` and every other widget's code is unchanged.
